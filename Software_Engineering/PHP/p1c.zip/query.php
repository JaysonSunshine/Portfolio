<!DOCTYPE html>
<html>
<body>

<h1>Movie Database</h1>

<h2>Input Pages</h2>
<a href="add_actor_director.php">Add actor and/or director</a> <br>
<a href="add_movie.php">Add Movie Information</a> <br>
<a href="add_comments.php">Add Movie Comments</a> <br>
<a href="add_actor_movie.php">Add actor to movie</a> <br>
<a href="add_director_movie.php">Add director to movie</a> <br>



<h2>Browsing Pages</h2>
<a href="browse_actor.php">Browse Actors</a> <br>
<a href="browse_movie.php">Browse Movies</a>

<h2>Search Page</h2>
<a href="search.php">Search</a> <br>

<h2>My Search Pages</h2>
<a href="search_database.php">SQL Search database</a> <br><br><br>

</body>
</html>